﻿public class ej3
{
    static void Main(string[] args)
    {

        int edad;
        int meses;
        Console.WriteLine("Que edad tienes??");
        edad = int.Parse(Console.ReadLine());

        meses = (edad * 12) + 10;

        Console.WriteLine($"Has vivido {meses} meses");


    }
}
