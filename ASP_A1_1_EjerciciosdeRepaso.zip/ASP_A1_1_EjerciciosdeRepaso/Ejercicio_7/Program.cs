﻿public class ej7
{
    static void Main(string[] args)
    {
        String nombreCorredor;
        Console.WriteLine("Cual es el nombre del corredor");
        nombreCorredor = Console.ReadLine();
        double promedio = CalcularPromedio();
        Console.WriteLine($"El tiempo medio de {nombreCorredor} es {promedio}");

    }

    public static double CalcularPromedio()
    {
        double total = 0;

        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine($"Dame el tiempo del corredor {i + 1}:");
            double tiempo = double.Parse(Console.ReadLine());
            total = total + tiempo;
        }

        double media = total / 3;
        return media;
    }
}

