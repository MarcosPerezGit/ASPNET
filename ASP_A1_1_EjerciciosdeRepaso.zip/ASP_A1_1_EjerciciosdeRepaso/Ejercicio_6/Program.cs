﻿public class ej6
{
    static void Main(string[] args)
    {
        int numero;

        Console.WriteLine("Pasame un numero y te digo si es par o impar");
        numero = int.Parse(Console.ReadLine());

        if (numero % 2 == 0)
        {
            Console.WriteLine("El numero es par");
        }
        else
        {
            Console.WriteLine("El numero es impar");
        }

    }
}
