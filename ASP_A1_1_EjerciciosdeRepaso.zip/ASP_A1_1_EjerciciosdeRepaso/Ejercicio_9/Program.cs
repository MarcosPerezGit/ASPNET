﻿public class ej9
{
    static void Main(string[] args)
    {
        double total = 0;

        List <Producto> productos = new List<Producto>();

        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine($"Pasame el nombre del producto {i + 1}");
            string nombre = Console.ReadLine();

            Console.WriteLine($"Pasame la descripcion del producto {i + 1}");
            string descripcion = Console.ReadLine();

            Console.WriteLine($"Pasame el precio del producto {i + 1}");
            double precio = double.Parse(Console.ReadLine());

            Producto producto = new Producto(nombre, descripcion, precio);
            productos.Add(producto);
            total = total + precio;
        }

        Console.WriteLine("\n--- PRODUCTOS INTRODUCIDOS ---");
        foreach (Producto p in productos)
        {
            p.Datos();
        }
        Console.WriteLine($"El precio total de los productos es {total}");
    }
}

public class Producto
{
    string nombre;
    string descripcion;
    double precio;

    public Producto(string nombre, string descripcion, double precio)
    {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public void Datos()
    {
        Console.WriteLine($"El nombrde el producto es {nombre}, es un producto de tipo {descripcion} y cuesta {precio}€");
    }
}

