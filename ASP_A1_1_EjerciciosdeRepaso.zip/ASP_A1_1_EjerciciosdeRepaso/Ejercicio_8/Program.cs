﻿public class ej8
{
    static void Main(string[] args)
    {
        Producto producto1 = new Producto("Mortadela", "Tiene aceitunas", 5.99);
        Producto producto2 = new Producto("Chorizo", "Es picante", 7.99);
        Producto producto3 = new Producto("Yogurt Griego", "Tiene pepitas de chocolate", 9.99);

        producto1.Datos();
        producto2.Datos();
        producto3.Datos();

    }
}
public class Producto
{
    string nombre;
    string descripcion;
    double precio;

    public Producto(string nombre, string descripcion, double precio)
    {
        this.nombre = nombre;       
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public void Datos()
    {
        Console.WriteLine($"El nombrde el producto es {nombre}, es un producto de tipo {descripcion} y cuesta {precio}");
    }
}
