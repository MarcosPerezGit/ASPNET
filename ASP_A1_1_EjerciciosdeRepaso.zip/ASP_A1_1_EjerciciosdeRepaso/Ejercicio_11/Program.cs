﻿public class Producto
{
    protected string nombre;
    protected string descripcion;
    protected double precio;

    public Producto(string nombre, string descripcion, double precio)
    {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }

    public string Descripcion
    {
        get { return descripcion; }
        set { descripcion = value; }
    }

    public virtual double Precio
    {
        get { return precio; }
        set { precio = value; }
    }

    public virtual void Datos()
    {
        Console.WriteLine($"El nombre del producto es {nombre}, es un producto de tipo {descripcion} y cuesta {precio}");
    }
}

public class ProductoDetallado : Producto
{
    private Dictionary<string, string> caracteristicas = new Dictionary<string, string>();

    public ProductoDetallado(string nombre, string descripcion, double precio)
        : base(nombre, descripcion, precio)
    {
    }

    public string this[string clave]
    {
        get
        {
            if (caracteristicas.ContainsKey(clave))
                return caracteristicas[clave];
            else
                return "Característica no encontrada";
        }
        set
        {
            caracteristicas[clave] = value;
        }
    }

    public override double Precio
    {
        get { return precio; }
        set
        {
            if (value < 0)
                throw new ArgumentException("El precio no puede ser negativo.");
            precio = value;
        }
    }

    public override void Datos()
    {
        base.Datos(); 
        Console.WriteLine("Características adicionales:");
        foreach (var item in caracteristicas)
        {
            Console.WriteLine($"- {item.Key}: {item.Value}");
        }
        Console.WriteLine(); 
    }
}

class Program
{
    static void Main(string[] args)
    {
        ProductoDetallado p1 = new ProductoDetallado("Laptop", "Electrónica", 1200);
        p1["Peso"] = "1.5 kg";
        p1["Color"] = "Gris";
        p1["Garantía"] = "2 años";

        ProductoDetallado p2 = new ProductoDetallado("Mesa", "Mueble", 250);
        p2["Material"] = "Madera";
        p2["Color"] = "Roble";

        ProductoDetallado p3 = new ProductoDetallado("Auriculares", "Accesorio", 80);
        p3["Tipo"] = "Bluetooth";
        p3["Autonomía"] = "20 horas";

        p1.Datos();
        p2.Datos();
        p3.Datos();
    }
}
