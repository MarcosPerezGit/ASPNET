﻿public class ej4
{
    static void Main(string[] args)
    {
        int num1;
        int num2;
        Console.WriteLine("COMPARACION DE NUMEROS");
        Console.WriteLine("Dame el primer numero");
        num1 = int.Parse(Console.ReadLine());
        Console.WriteLine("Dame el segundo numero");
        num2 = int.Parse(Console.ReadLine());

        if (num1 > num2)
        {
            Console.WriteLine($"El numero mayor es {num1}");
        }
        else if (num1 < num2) {
            Console.WriteLine($"El numero mayor es {num2}");
        }
        else
        {
            Console.WriteLine("Los numeros son iguales");

        }
    }
}
