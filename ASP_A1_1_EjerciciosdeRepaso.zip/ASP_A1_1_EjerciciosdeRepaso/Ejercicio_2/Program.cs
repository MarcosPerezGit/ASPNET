﻿public class ej2
{
    static void Main(string[] args)
    {
        String nombre;

        Console.WriteLine("Como te llamas?");
        nombre = Console.ReadLine();

        Console.WriteLine($"Hola {nombre}, bienvenido al programa");

    }
}
