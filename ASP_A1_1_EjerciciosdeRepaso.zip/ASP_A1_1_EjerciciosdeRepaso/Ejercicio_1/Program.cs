﻿using System;

public class ej1
{
    static void Main(string[] args)
    {
        int num1;
        int num2;
        int total;
        Console.WriteLine("Vamos a hacer una suma");
        Console.WriteLine("Dame el primer numero");
        num1 = int.Parse(Console.ReadLine());

        Console.WriteLine("Dame el segundo numero");
        num2 = int.Parse(Console.ReadLine());

        total = num1 + num2;

        Console.Write($"El total de {num1} + {num2} es {total}.");


    }
}