﻿public class ej5
{
    static void Main(string[] args)
    {
        int nota;

        Console.WriteLine("Dime una nota y de digo si has aprobado");
        nota = int.Parse(Console.ReadLine());

        if (nota >= 5)
        {
            Console.WriteLine("Has Aprobado");
        }
        else
        {
            Console.WriteLine("Has Suspendido");
        }
    }
}