﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Ejercicio3_ListaSegura
{
    public static void Main(string[] args)
    {
        var palabras = new List<string> { "A", "B", "C", "D", "E" };
        for (int i = 0; i < 3; i++)
        {
            Console.Write("Ingresa índice: ");
            string indiceInput = Console.ReadLine();
            if (!int.TryParse(indiceInput, out int indice))
            {
                Console.WriteLine("Índice no válido");
                continue;
            }
            string palabra = palabras.ElementAtOrDefault(indice);
            if (palabra != null)
            {
                Console.WriteLine($"Palabra: \"{palabra}\"");
            }
            else
            {
                Console.WriteLine("Índice fuera de rango");
            }
        }
    }
}