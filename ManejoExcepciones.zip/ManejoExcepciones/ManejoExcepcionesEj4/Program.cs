﻿using System;
using System.Collections.Generic;

public class Ejercicio4_ManejoMixto
{
    public static void Main(string[] args)
    {
        var productos = new Dictionary<string, int>
        {
            { "Laptop", 1500 },
            { "Mouse", 25 },
            { "Teclado", 45 }
        };

        for (int i = 0; i < 3; i++)
        {
            Console.Write("Ingresa producto: ");
            string input = Console.ReadLine();

            // Separar producto y cantidad si existe
            string producto = input;
            int cantidad = 1; // Valor por defecto
            if (input.Contains(","))
            {
                var partes = input.Split(',');
                producto = partes[0].Trim();
                // Tratar de leer cantidad
                string cantidadTexto = partes.Length > 1 ? partes[1].Replace("cantidad:", "").Trim() : "1";
                if (!int.TryParse(cantidadTexto, out cantidad))
                {
                    Console.WriteLine("Cantidad no válida");
                    continue;
                }
            }

            if (!productos.TryGetValue(producto, out int precio))
            {
                Console.WriteLine("Producto no encontrado");
                continue;
            }

            try
            {
                int total = checked(precio * cantidad);
                Console.WriteLine($"Total: {total}");
            }
            catch (Exception)
            {
                Console.WriteLine("Error en el cálculo del total");
            }
        }
    }
}