﻿using System;
using System.Collections.Generic;

public class Ejercicio2_DiccionarioSeguro
{
    public static void Main(string[] args)
    {
        var alumnos = new Dictionary<string, int>
        {
            { "Ana", 25 },
            { "Luis", 30 }
        };
        for (int i = 0; i < 2; i++)
        {
            Console.Write("Ingresa nombre del alumno: ");
            string nombre = Console.ReadLine();
            if (alumnos.TryGetValue(nombre, out int edad))
            {
                Console.WriteLine($"Edad: {edad}");
            }
            else
            {
                Console.WriteLine("Alumno no encontrado");
            }
        }
    }
}