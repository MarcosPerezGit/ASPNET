﻿namespace IntercambioDatos2_1.Models
{
    public class PerfilViewModel
    {
        public required string Nombre { get; set; }
        public required string Email { get; set; }
        public bool EsAdmin { get; set; }
    }
}
