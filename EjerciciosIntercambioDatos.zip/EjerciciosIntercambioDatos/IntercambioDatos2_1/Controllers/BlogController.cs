﻿using Microsoft.AspNetCore.Mvc;

namespace IntercambioDatos2_1.Controllers
{
    public class BlogController : Controller
    {
        // GET: /Blog/Articulo/{id}
        [HttpGet]
        public IActionResult Articulo(int id)
        {
            ViewBag.Mensaje = $"Cargando artículo ID: {id}";
            return View(); // Renderiza Views/Blog/Articulo.cshtml
        }

        // Página con enlace de ejemplo
        // GET: /Blog
        [HttpGet]
        public IActionResult Index()
        {
            return View(); // Renderiza Views/Blog/Index.cshtml
        }
    }
}

