﻿using IntercambioDatos1_1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IntercambioDatos1_1.Controllers
{
    public class PerfilController : Controller
    {
        // GET: /Perfil
        public IActionResult Perfil()
        {
            // Datos ficticios (mock)
            var model = new PerfilViewModel
            {
                Nombre = "María López",
                Email = "maria.lopez@example.com",
                EsAdmin = true
            };

            // Pasar el modelo fuertemente tipado a la vista
            return View(model); // Buscará Views/Perfil/Perfil.cshtml
        }
    }
}