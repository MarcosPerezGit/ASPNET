﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IntercambioDatos2_2.Controllers
{
    public class PerfilController : Controller
    {
        // GET: /Perfil/Perfil
        public IActionResult Perfil()
        {
            ViewBag.Mensaje = "Bienvenido al perfil (simulado).";
            return View(); // Renderiza Views/Perfil/Perfil.cshtml
        }
    }
}
