﻿using IntercambioDatos2_2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IntercambioDatos2_2.Controllers
{
    public class AuthController : Controller
    {
        // GET: /Auth/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View(); // Renderiza Views/Auth/Login.cshtml
        }

        // POST: /Auth/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginModel model)
        {
            // Model binding capturará Usuario y Contrasena desde el formulario
            if (!ModelState.IsValid)
            {
                // Por simplicidad, retornamos la vista con el modelo
                return View(model);
            }

            if (model.Usuario == "admin")
            {
                // Redirigir a Perfil (del Ej 1.1). Incluimos un PerfilController mínimo para que funcione.
                return RedirectToAction("Perfil", "Perfil");
            }

            // Si no es admin, mostramos un mensaje simple y volvemos al formulario
            ViewBag.Error = "Credenciales inválidas. Prueba con usuario 'admin'.";
            return View(model);
        }
    }
}