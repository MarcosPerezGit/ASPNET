﻿namespace IntercambioDatos2_2.Models
{
    public class LoginModel
    {
        public string Usuario { get; set; } = string.Empty;
        public string Contrasena { get; set; } = string.Empty;
    }
}
