﻿using IntercambioDatos1_2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IntercambioDatos1_2.Controllers
{    public class PerfilController : Controller
    {
        // GET: /Perfil
        public IActionResult Perfil()
        {
            // ViewModel con datos ficticios para la vista
            var model = new PerfilViewModel
            {
                Nombre = "Carlos Pérez",
                Email = "carlos.perez@example.com",
                EsAdmin = false
            };

            // Datos auxiliares usando ViewBag y ViewData
            ViewBag.TituloPagina = "Mi Perfil de Usuario";
            ViewData["FechaActual"] = DateTime.Now.ToShortDateString();

            // Pasar el modelo a la vista
            return View(model); // Renderiza Views/Perfil/Perfil.cshtml
        }
    }
}