﻿using IntercambioDatos3_1.Models;
using Microsoft.AspNetCore.Mvc;

namespace IntercambioDatos3_1.Controllers
{
    public class UsuariosController : Controller
{
    // GET: /Usuarios/ListadoUsuarios
    [HttpGet]
    public IActionResult ListadoUsuarios()
    {
        // Simplemente retorna la vista. TempData será leído allí si existe.
        return View(); // Renderiza Views/Usuarios/ListadoUsuarios.cshtml
    }

    // POST: /Usuarios/CrearUsuario
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult CrearUsuario(UsuarioModel model)
    {
        if (!ModelState.IsValid)
        {
            // En un caso real, mostrarías errores. Aquí volvemos a la lista para simplificar.
            TempData["MensajeExito"] = "Datos inválidos. Revisa el formulario.";
            return RedirectToAction(nameof(ListadoUsuarios));
        }

        // Simular creación del usuario (persistencia omitida)
        // ...

        TempData["MensajeExito"] = "Usuario creado correctamente.";
        return RedirectToAction(nameof(ListadoUsuarios));
    }

    // Página con formulario sencillo para crear usuario (opcional para probar)
    // GET: /Usuarios/Nuevo
    [HttpGet]
    public IActionResult Nuevo()
    {
        return View(); // Renderiza Views/Usuarios/Nuevo.cshtml
    }
}
}